## Description

Empty directory used as IPC between SDK containers and with the extern.

Used for files required by tests or to share ADA handle policy id between containers, etc...
