#!/usr/bin/env bash

export PATH=$PWD/bin:$PATH

cardano-node run \
  --config                          'network-files/configuration.yaml' \
  --topology                        'network-files/node-sp2/topology.json' \
  --database-path                   'network-files/node-sp2/db' \
  --socket-path                     'network-files/node-sp2/node.sock' \
  --shelley-kes-key                 'network-files/node-sp2/kes.skey' \
  --shelley-vrf-key                 'network-files/node-sp2/vrf.skey' \
  --byron-delegation-certificate    'network-files/node-sp2/byron-delegation.cert' \
  --byron-signing-key               'network-files/node-sp2/byron-delegate.key' \
  --shelley-operational-certificate 'network-files/node-sp2/opcert.cert' \
  --port                            3002 \
  | tee -a 'network-files/node-sp2/node.log'

wait
