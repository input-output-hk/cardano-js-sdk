#!/usr/bin/env bash

export PATH=$PWD/bin:$PATH

cardano-node run \
  --config                          'network-files/configuration.yaml' \
  --topology                        'network-files/node-sp7/topology.json' \
  --database-path                   'network-files/node-sp7/db' \
  --socket-path                     'network-files/node-sp7/node.sock' \
  --shelley-kes-key                 'network-files/node-sp7/kes.skey' \
  --shelley-vrf-key                 'network-files/node-sp7/vrf.skey' \
  --byron-delegation-certificate    'network-files/node-sp7/byron-delegation.cert' \
  --byron-signing-key               'network-files/node-sp7/byron-delegate.key' \
  --shelley-operational-certificate 'network-files/node-sp7/opcert.cert' \
  --port                            3007 \
  | tee -a 'network-files/node-sp7/node.log'

wait
