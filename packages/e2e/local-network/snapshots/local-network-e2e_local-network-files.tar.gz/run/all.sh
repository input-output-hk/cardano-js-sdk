#!/usr/bin/env bash


export PATH=$PWD/bin:$PATH

network-files/node-sp1.sh &
network-files/node-sp2.sh &
network-files/node-sp3.sh &
network-files/node-sp4.sh &
network-files/node-sp5.sh &
network-files/node-sp6.sh &
network-files/node-sp7.sh &
network-files/node-sp8.sh &
network-files/node-sp9.sh &
network-files/node-sp10.sh &
network-files/node-sp11.sh &

wait
